# Сборка AAB на GitHub

Вкладка Actions → Build Android AAB → Run workflow.

После завершения открой результат запуска и скачай артефакт `SiraQuiz-release-AAB`.

Примечание: эта базовая сборка создаёт release AAB без настроенного upload-keystore. Для загрузки в Google Play потребуется подписать релиз своим ключом. Следующий шаг — настроить безопасную подпись через GitHub Secrets.
